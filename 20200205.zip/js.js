function test_1(a)
{
  var i1 = parseInt(document.getElementById("KZT").value);
  if (a==1) {
    document.getElementById("result").value= (i1/380).toFixed(0);

  }
  else{

  document.getElementById("result").value=(i1/419).toFixed(0);
}

//  var i3 = document.querySelector("dollar/380").value
  //var i4 = document.querySelector("euro/400").value
}
