function test_1(a)
{
  var tenge = parseInt(document.getElementById("KZT").value);
  var result = 0;
  if (a==="USD")
  {
    //console.log("check USD");
    result = (tenge/380);
  }
  if (a==="EURO")
  {
    //console.log("check EURO");
    result = (tenge/420);
  }
  document.getElementById("result").value = result.toFixed(2);
}
